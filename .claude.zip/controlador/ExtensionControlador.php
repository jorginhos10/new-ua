<?php

require_once __DIR__ . '/../modelo/GastoExtension.php';
require_once __DIR__ . '/../modelo/IngresoExtension.php';
require_once __DIR__ . '/../modelo/DuplicadorFilas.php';
require_once __DIR__ . '/../modelo/Linea.php';
require_once __DIR__ . '/../modelo/Motor.php';
require_once __DIR__ . '/../modelo/Proyecto.php';
require_once __DIR__ . '/../modelo/Rubro.php';
require_once __DIR__ . '/../modelo/ContratoComun.php';
require_once __DIR__ . '/../modelo/AnioPresupuestal.php';
require_once __DIR__ . '/../modelo/Sede.php';
require_once __DIR__ . '/../modelo/AutogestionItem.php';
require_once __DIR__ . '/../modelo/AutogestionPorcentaje.php';
require_once __DIR__ . '/../modelo/Dependencia.php';
require_once __DIR__ . '/../modelo/Usuario.php';
require_once __DIR__ . '/../modelo/Rol.php';
require_once __DIR__ . '/../modelo/Mensaje.php';
require_once __DIR__ . '/../modelo/PeticionArchivada.php';

class ExtensionControlador
{
    private GastoExtension $modeloGasto;
    private IngresoExtension $modeloIngreso;
    private Linea $modeloLinea;
    private Motor $modeloMotor;
    private Proyecto $modeloProyecto;
    private Rubro $modeloRubro;
    private ContratoComun $modeloContratoComun;
    private AnioPresupuestal $modeloAnio;
    private Sede $modeloSede;
    private AutogestionItem $modeloAutogestion;
    private AutogestionPorcentaje $modeloPorcentaje;
    private Dependencia $modeloDependencia;
    private Usuario $modeloUsuario;
    private Rol $modeloRol;
    private Mensaje $modeloMensaje;

    private const CAMPOS_REQUERIDOS_EGRESO = [
        'sede_id',
        'anio_presupuestal_id',
        'categoria',
        'dependencia',
        'proyecto_id',
        'actividad',
        'rubro_id',
        'autogestion_id',
        'insumo',
        'cantidad',
        'costo_unitario',
    ];

    private const CATEGORIAS_EGRESO = [
        'Gastos',
        'Inversiones',
    ];

    private const AUTOMATICO_SEDE_ID = 1;
    private const AUTOMATICO_LINEA_ID = 5;
    private const AUTOMATICO_MOTOR_ID = 1;
    private const AUTOMATICO_PROYECTO_ID = 1;
    private const AUTOMATICO_RUBRO_TEXTO = 'SERVICIOS DE DISTRIBUCIÓN DE ELECTRICIDAD, GAS Y AGUA (POR CUENTA PROPIA)';
    private const AUTOMATICO_OBJETO_PROYECTO_PAA = 'SERVICIOS DE DISTRIBUCIÓN DE ELECTRICIDAD, GAS Y AGUA (POR CUENTA PROPIA)';
    private const AUTOMATICO_INSUMO = 'EXCEDENTES NIVEL CENTRAL';
    private const AUTOMATICO_ACTIVIDAD = 'Contribución al uso de servicios públicos';
    private const AUTOMATICO_MES = 2;

    public function __construct()
    {
        $this->modeloGasto = new GastoExtension();
        $this->modeloIngreso = new IngresoExtension();
        $this->modeloLinea = new Linea();
        $this->modeloMotor = new Motor();
        $this->modeloProyecto = new Proyecto();
        $this->modeloRubro = new Rubro();
        $this->modeloContratoComun = new ContratoComun();
        $this->modeloAnio = new AnioPresupuestal();
        $this->modeloSede = new Sede();
        $this->modeloAutogestion = new AutogestionItem();
        $this->modeloPorcentaje = new AutogestionPorcentaje();
        $this->modeloDependencia = new Dependencia();
        $this->modeloUsuario = new Usuario();
        $this->modeloRol = new Rol();
        $this->modeloMensaje = new Mensaje();
    }

    public function index(): void
    {
        if (empty($_SESSION['usuario_id'])) {
            header('Location: index.php?ruta=login');
            exit;
        }

        if ($_SESSION['usuario_rol'] !== 'administrador') {
            header('Location: index.php?ruta=dashboard');
            exit;
        }

        $error = '';
        $exito = '';
        $tab = ($_GET['tab'] ?? 'ingresos') === 'egresos' ? 'egresos' : 'ingresos';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tab = ($_POST['tab'] ?? 'ingresos') === 'egresos' ? 'egresos' : 'ingresos';
            $accion = $_POST['accion'] ?? '';

            if ($accion === 'enviar_todo') {
                [$error, $exito] = $this->enviarTodo();
            } elseif ($tab === 'egresos' && $accion === 'actualizar') {
                [$error, $exito] = $this->actualizarEgreso();
            } elseif ($tab === 'egresos' && $accion === 'eliminar') {
                [$error, $exito] = $this->eliminarEgreso();
            } elseif ($tab === 'ingresos' && $accion === 'actualizar') {
                [$error, $exito] = $this->actualizarIngreso();
            } elseif ($tab === 'ingresos' && $accion === 'eliminar') {
                [$error, $exito] = $this->eliminarIngreso();
            } elseif ($accion === 'eliminar_seleccionados') {
                [$error, $exito] = $this->eliminarSeleccionados($tab);
            } elseif ($accion === 'duplicar_seleccionados') {
                [$error, $exito] = $this->duplicarSeleccionados($tab);
            } else {
                [$error, $exito] = $tab === 'ingresos' ? $this->guardarIngreso() : $this->guardarEgreso();
            }
        }

        $lineas = $this->modeloLinea->obtenerTodas();
        $motores = $this->modeloMotor->obtenerTodos();
        $proyectos = $this->modeloProyecto->obtenerTodos();
        $rubros = $this->modeloRubro->obtenerActivosPorCategoria('autogestion');
        $contratosComunes = $this->modeloContratoComun->obtenerActivos();
        $aniosActivos = $this->modeloAnio->obtenerActivos();
        $sedes = $this->modeloSede->obtenerTodas();
        $autogestionItems = $this->modeloAutogestion->obtenerActivos('extension');
        $categoriasEgreso = self::CATEGORIAS_EGRESO;
        $roles = $this->modeloRol->obtenerTodos();
        $usuariosPorDependenciaYRol = $this->modeloUsuario->obtenerMapaPorDependenciaYRol();

        $usuarioActual = $this->modeloUsuario->obtenerPorId((int) $_SESSION['usuario_id']);
        $dependenciaUsuarioId = !empty($usuarioActual['dependencia_id']) ? (int) $usuarioActual['dependencia_id'] : null;
        $dependenciaUsuario = $dependenciaUsuarioId !== null ? $this->modeloDependencia->obtenerPorId($dependenciaUsuarioId) : null;
        $dependenciaUsuarioEsRaiz = $dependenciaUsuario !== null && !empty($dependenciaUsuario['es_raiz_superadmin']);

        $dependenciasSugeridas = [];
        $tieneHijas = false;
        $dependenciaPorDefecto = null;

        if ($dependenciaUsuario !== null) {
            $descendientes = $this->modeloDependencia->obtenerDescendientesPlano($dependenciaUsuarioId);
            $tieneHijas = !empty($descendientes);

            if (!$dependenciaUsuarioEsRaiz) {
                $dependenciasSugeridas[] = $dependenciaUsuario['nombre'];
                $dependenciaPorDefecto = $dependenciaUsuario['nombre'];
            }

            foreach ($descendientes as $descendiente) {
                if (!empty($descendiente['es_raiz_superadmin'])) {
                    continue;
                }

                $dependenciasSugeridas[] = $descendiente['nombre'];
            }
        }

        $anioSeleccionadoId = 0;

        if (!empty($aniosActivos)) {
            $anioSeleccionadoId = isset($_GET['anio_id']) ? (int) $_GET['anio_id'] : (int) $aniosActivos[0]['id'];

            $idsValidos = array_map('intval', array_column($aniosActivos, 'id'));
            if (!in_array($anioSeleccionadoId, $idsValidos, true)) {
                $anioSeleccionadoId = (int) $aniosActivos[0]['id'];
            }
        }

        $autogestionSeleccionadoId = 0;

        if (!empty($autogestionItems)) {
            $autogestionSeleccionadoId = isset($_GET['autogestion_id']) ? (int) $_GET['autogestion_id'] : (int) $autogestionItems[0]['id'];

            $idsValidosAutogestion = array_map('intval', array_column($autogestionItems, 'id'));
            if (!in_array($autogestionSeleccionadoId, $idsValidosAutogestion, true)) {
                $autogestionSeleccionadoId = (int) $autogestionItems[0]['id'];
            }
        }

        if ($anioSeleccionadoId > 0 && $autogestionSeleccionadoId > 0) {
            $gastos = $tab === 'ingresos'
                ? $this->modeloIngreso->obtenerPorAnioYAutogestion($anioSeleccionadoId, $autogestionSeleccionadoId)
                : $this->modeloGasto->obtenerPorAnioYAutogestion($anioSeleccionadoId, $autogestionSeleccionadoId);
            $gastosEgresos = $tab === 'egresos'
                ? $gastos
                : $this->modeloGasto->obtenerPorAnioYAutogestion($anioSeleccionadoId, $autogestionSeleccionadoId);
        } else {
            $gastos = [];
            $gastosEgresos = [];
        }

        $dependenciasTodas = $this->modeloDependencia->obtenerActivasParaEnvio();

        $egresoParaEditar = null;
        $ingresoParaEditar = null;
        if (isset($_GET['editar_id']) && ctype_digit((string) $_GET['editar_id'])) {
            if ($tab === 'egresos') {
                $egresoParaEditar = $this->modeloGasto->obtenerPorId((int) $_GET['editar_id']);
            } else {
                $ingresoParaEditar = $this->modeloIngreso->obtenerPorId((int) $_GET['editar_id']);
            }
        }
        $volverEdicion = $_GET['volver'] ?? '';

        $anioSeleccionado = null;
        foreach ($aniosActivos as $anioFila) {
            if ((int) $anioFila['id'] === $anioSeleccionadoId) {
                $anioSeleccionado = $anioFila;
                break;
            }
        }

        $totalGastado = array_sum(array_map(static fn (array $g): float => (float) $g['valor_total'], $gastos));
        $totalEjecutado = array_sum(array_map(static fn (array $g): float => (float) $g['valor_total'], $gastosEgresos));
        $presupuestoAnio = ($anioSeleccionadoId > 0 && $autogestionSeleccionadoId > 0)
            ? $this->modeloIngreso->obtenerTotalPorAnioYAutogestion($anioSeleccionadoId, $autogestionSeleccionadoId)
            : 0.0;
        $porcentajeGastado = $presupuestoAnio > 0 ? min(100, ($totalEjecutado / $presupuestoAnio) * 100) : 0.0;
        $puedeEnviarTodo = $presupuestoAnio > 0 && abs($presupuestoAnio - $totalEjecutado) < 0.01;

        $totalCostos = 0.0;
        $totalInversion = 0.0;
        $totalExcedentes = 0.0;

        foreach ($gastosEgresos as $gasto) {
            $valor = (float) $gasto['valor_total'];
            $categoria = $gasto['categoria'];

            if ($categoria === 'Gastos' || str_starts_with($categoria, 'Costos')) {
                $totalCostos += $valor;
            } elseif ($categoria === 'Inversiones' || str_starts_with($categoria, 'Inversión')) {
                $totalInversion += $valor;
            } elseif (str_starts_with($categoria, 'Excedentes')) {
                $totalExcedentes += $valor;
            }
        }

        $pctCostos = $presupuestoAnio > 0 ? min(100, ($totalCostos / $presupuestoAnio) * 100) : 0.0;
        $pctInversion = $presupuestoAnio > 0 ? min(100, ($totalInversion / $presupuestoAnio) * 100) : 0.0;
        $pctExcedentes = $presupuestoAnio > 0 ? min(100, ($totalExcedentes / $presupuestoAnio) * 100) : 0.0;

        $diaActual = (int) date('z') + 1;
        $totalDiasAnio = date('L') ? 366 : 365;

        require __DIR__ . '/../vista/extension/index.php';
    }

    private function guardarEgreso(): array
    {
        [$datos, $error] = $this->validarDatosEgreso();

        if ($error !== '') {
            return [$error, ''];
        }

        $ingresosDisponibles = $this->modeloIngreso->obtenerTotalPorAnioYAutogestion($datos['anio_presupuestal_id'], $datos['autogestion_id']);
        $egresosActuales = $this->modeloGasto->obtenerTotalPorAnioYAutogestion($datos['anio_presupuestal_id'], $datos['autogestion_id']);
        $nuevoValor = $datos['cantidad'] * $datos['costo_unitario'];

        if ($egresosActuales + $nuevoValor > $ingresosDisponibles) {
            $disponible = max(0, $ingresosDisponibles - $egresosActuales);

            return ["Este egreso supera los ingresos disponibles de este ítem de autogestión. Disponible: " . number_format($disponible, 2) . '.', ''];
        }

        $errorCategoria = $this->validarLimiteCategoria($datos['anio_presupuestal_id'], (int) $datos['autogestion_id'], $datos['categoria'], $nuevoValor, $ingresosDisponibles);

        if ($errorCategoria !== '') {
            return [$errorCategoria, ''];
        }

        try {
            $this->modeloGasto->crear($datos);
        } catch (PDOException $excepcion) {
            return ['No se pudo registrar el egreso. Verifica el año, la sede, la línea, el motor, el proyecto y el rubro seleccionados.', ''];
        }

        return ['', 'Egreso registrado correctamente.'];
    }

    private function actualizarEgreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloGasto->obtenerPorId($id) : null;

        if ($existente === null || $existente['tipo_automatico'] !== null) {
            return ['El egreso que intentas editar no existe.', ''];
        }

        [$datos, $error] = $this->validarDatosEgreso();

        if ($error !== '') {
            return [$error, ''];
        }

        $ingresosDisponibles = $this->modeloIngreso->obtenerTotalPorAnioYAutogestion($datos['anio_presupuestal_id'], $datos['autogestion_id']);
        $egresosActuales = $this->modeloGasto->obtenerTotalPorAnioYAutogestion($datos['anio_presupuestal_id'], $datos['autogestion_id']);
        $egresosActuales -= (float) $existente['valor_total'];
        $nuevoValor = $datos['cantidad'] * $datos['costo_unitario'];

        if ($egresosActuales + $nuevoValor > $ingresosDisponibles) {
            $disponible = max(0, $ingresosDisponibles - $egresosActuales);

            return ["Este egreso supera los ingresos disponibles de este ítem de autogestión. Disponible: " . number_format($disponible, 2) . '.', ''];
        }

        $valorExcluidoCategoria = $existente['categoria'] === $datos['categoria'] ? (float) $existente['valor_total'] : 0.0;
        $errorCategoria = $this->validarLimiteCategoria($datos['anio_presupuestal_id'], (int) $datos['autogestion_id'], $datos['categoria'], $nuevoValor, $ingresosDisponibles, $valorExcluidoCategoria);

        if ($errorCategoria !== '') {
            return [$errorCategoria, ''];
        }

        try {
            $this->modeloGasto->actualizar($id, $datos);
        } catch (PDOException $excepcion) {
            return ['No se pudo actualizar el egreso. Verifica el año, la sede, la línea, el motor, el proyecto y el rubro seleccionados.', ''];
        }

        (new PeticionArchivada())->sincronizarDesdeOrigen('gasto_extension', $id, $nuevoValor, $datos['dependencia']);

        $destino = !empty($_POST['volver'])
            ? $_POST['volver']
            : 'index.php?ruta=extension&tab=egresos&anio_id=' . $datos['anio_presupuestal_id'] . '&autogestion_id=' . $datos['autogestion_id'];
        header('Location: ' . $destino);
        exit;
    }

    private function validarLimiteCategoria(int $anioPresupuestalId, int $autogestionId, string $categoria, float $nuevoValor, float $totalIngresos, float $valorExcluido = 0.0): string
    {
        $mapaCategoriaPorcentaje = ['Gastos' => 'costos', 'Inversiones' => 'inversiones'];
        $clavePorcentaje = $mapaCategoriaPorcentaje[$categoria] ?? null;

        if ($clavePorcentaje === null) {
            return '';
        }

        $porcentajes = $this->modeloPorcentaje->obtenerPorModulo('extension');

        if ($porcentajes[$clavePorcentaje] === null) {
            return '';
        }

        $limiteCategoria = round($totalIngresos * (float) $porcentajes[$clavePorcentaje] / 100, 2);
        $totalCategoriaActual = $this->modeloGasto->obtenerTotalPorAnioAutogestionYCategoria($anioPresupuestalId, $autogestionId, $categoria) - $valorExcluido;

        if ($totalCategoriaActual + $nuevoValor > $limiteCategoria) {
            $disponibleCategoria = max(0, $limiteCategoria - $totalCategoriaActual);

            return "Este egreso supera el porcentaje disponible para {$categoria}. Disponible: " . number_format($disponibleCategoria, 2) . '.';
        }

        return '';
    }

    private function enviarTodo(): array
    {
        $anioId = (int) ($_POST['anio_presupuestal_id'] ?? 0);
        $autogestionId = (int) ($_POST['autogestion_id'] ?? 0);
        $dependenciaDestinoNombre = trim($_POST['dependencia_destino'] ?? '');
        $rolDestinatarioId = (int) ($_POST['rol_destinatario_id'] ?? 0);

        if ($anioId <= 0 || $autogestionId <= 0 || $dependenciaDestinoNombre === '' || $rolDestinatarioId <= 0) {
            return ['Selecciona a quién se enviará y el rol al que se enviarán los ingresos y egresos.', ''];
        }

        $rol = $this->modeloRol->obtenerPorId($rolDestinatarioId);

        if ($rol === null) {
            return ['El rol seleccionado no existe.', ''];
        }

        $dependenciaDestino = $this->modeloDependencia->obtenerPorNombre($dependenciaDestinoNombre);

        if ($dependenciaDestino === null) {
            return ['La dependencia destino seleccionada no existe.', ''];
        }

        $destinatarios = $this->modeloUsuario->obtenerPorDependenciaYRol((int) $dependenciaDestino['id'], $rolDestinatarioId);

        if (count($destinatarios) > 1) {
            $usuarioDestinatarioId = (int) ($_POST['usuario_destinatario_id'] ?? 0);
            $destinatarios = array_values(array_filter($destinatarios, static fn (array $u): bool => (int) $u['id'] === $usuarioDestinatarioId));

            if (empty($destinatarios)) {
                return ['Hay más de un usuario con el rol "' . $rol['nombre'] . '" en "' . $dependenciaDestinoNombre . '". Selecciona a quién remitir la petición.', ''];
            }
        }

        $totalIngresos = $this->modeloIngreso->obtenerTotalPorAnioYAutogestion($anioId, $autogestionId);
        $totalEgresos = $this->modeloGasto->obtenerTotalPorAnioYAutogestion($anioId, $autogestionId);

        if ($totalIngresos <= 0 || abs($totalIngresos - $totalEgresos) >= 0.01) {
            return ['Solo puedes enviar cuando el total de egresos sea igual al total de ingresos de este ítem de autogestión.', ''];
        }

        $enviadosIngresos = $this->modeloIngreso->enviarTodosBorrador($anioId, $autogestionId, $dependenciaDestinoNombre, $rolDestinatarioId);
        $enviadosEgresos = $this->modeloGasto->enviarTodosBorrador($anioId, $autogestionId, $dependenciaDestinoNombre, $rolDestinatarioId);

        if ($enviadosIngresos === 0 && $enviadosEgresos === 0) {
            return ['No hay ingresos ni egresos en borrador para enviar.', ''];
        }

        $remitenteId = (int) ($_SESSION['usuario_id'] ?? 0);

        foreach ($destinatarios as $destinatario) {
            $this->modeloMensaje->crear(
                $remitenteId,
                (int) $destinatario['id'],
                'Extensión enviada',
                'Se enviaron ' . $enviadosIngresos . ' ingreso(s) y ' . $enviadosEgresos . ' egreso(s) de Extensión para tu revisión.'
            );
        }

        if (empty($destinatarios)) {
            return ['', 'Se enviaron ' . $enviadosIngresos . ' ingreso(s) y ' . $enviadosEgresos . ' egreso(s), pero no se encontró ningún usuario con el rol "' . $rol['nombre'] . '" en "' . $dependenciaDestinoNombre . '" para notificar.'];
        }

        return ['', 'Se enviaron ' . $enviadosIngresos . ' ingreso(s) y ' . $enviadosEgresos . ' egreso(s) a ' . $destinatarios[0]['nombre'] . ' (' . $rol['nombre'] . ' en "' . $dependenciaDestinoNombre . '").'];
    }

    private function eliminarEgreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloGasto->obtenerPorId($id) : null;

        if ($existente === null || $existente['tipo_automatico'] !== null) {
            return ['El egreso que intentas eliminar no existe.', ''];
        }

        $this->modeloGasto->eliminar($id);

        return ['', 'Egreso eliminado correctamente.'];
    }

    private function validarDatosEgreso(): array
    {
        $datos = [];

        foreach ($_POST as $campo => $valor) {
            $datos[$campo] = is_string($valor) ? trim($valor) : $valor;
        }

        foreach (self::CAMPOS_REQUERIDOS_EGRESO as $campo) {
            if (($datos[$campo] ?? '') === '') {
                return [[], 'Todos los campos son obligatorios.'];
            }
        }

        if (!in_array($datos['categoria'], self::CATEGORIAS_EGRESO, true)) {
            return [[], 'Selecciona una categoría válida.'];
        }

        if (!is_numeric($datos['cantidad']) || (int) $datos['cantidad'] <= 0) {
            return [[], 'La cantidad debe ser un número entero mayor a 0.'];
        }

        if (!is_numeric($datos['costo_unitario']) || (float) $datos['costo_unitario'] < 0) {
            return [[], 'El costo unitario debe ser un número válido.'];
        }

        $meses = array_filter(
            array_map('intval', $datos['meses'] ?? []),
            static fn (int $mes): bool => $mes >= 1 && $mes <= 12
        );

        if (empty($meses)) {
            return [[], 'Selecciona al menos un mes de ejecución.'];
        }

        $meses = array_unique($meses);
        sort($meses);
        $datos['meses'] = implode(',', $meses);

        $proyectoPdi = $this->modeloProyecto->obtenerPorId((int) $datos['proyecto_id']);

        if ($proyectoPdi === null) {
            return [[], 'Selecciona un proyecto PDI válido.'];
        }

        $datos['anio_presupuestal_id'] = (int) $datos['anio_presupuestal_id'];
        $datos['sede_id'] = (int) $datos['sede_id'];
        $datos['proyecto_id'] = (int) $proyectoPdi['id'];
        $datos['motor_id'] = (int) $proyectoPdi['motor_id'];
        $datos['linea_id'] = (int) $proyectoPdi['linea_id'];
        $datos['rubro_id'] = (int) $datos['rubro_id'];
        $datos['autogestion_id'] = (int) $datos['autogestion_id'];
        $datos['cantidad'] = (int) $datos['cantidad'];
        $datos['costo_unitario'] = (float) $datos['costo_unitario'];

        return [$datos, ''];
    }

    private function validarDatosIngreso(): array
    {
        $anioPresupuestalId = (int) ($_POST['anio_presupuestal_id'] ?? 0);
        $autogestionId = (int) ($_POST['autogestion_id'] ?? 0);
        $dependencia = trim($_POST['dependencia'] ?? '');
        $conceptoAdicional = trim($_POST['concepto_adicional'] ?? '');
        $valorAdicional = is_numeric($_POST['valor_adicional'] ?? '') ? (float) $_POST['valor_adicional'] : 0.0;

        if ($anioPresupuestalId <= 0 || $autogestionId <= 0 || $dependencia === '') {
            return [[], [], 'El año presupuestal, la autogestión y la dependencia son obligatorios.'];
        }

        if ($valorAdicional < 0) {
            return [[], [], 'El valor del concepto adicional no puede ser negativo.'];
        }

        $nombresConcepto = $_POST['concepto'] ?? [];
        $cantidades = $_POST['cantidad_concepto'] ?? [];
        $valores = $_POST['valor_concepto'] ?? [];

        $conceptos = [];
        $totalFilas = max(count($nombresConcepto), count($cantidades), count($valores));

        for ($indice = 0; $indice < $totalFilas; $indice++) {
            $nombre = trim($nombresConcepto[$indice] ?? '');
            $cantidad = $cantidades[$indice] ?? '';
            $valor = $valores[$indice] ?? '';

            if ($nombre === '' && $cantidad === '' && $valor === '') {
                continue;
            }

            if ($nombre === '' || !is_numeric($cantidad) || (int) $cantidad <= 0 || !is_numeric($valor) || (float) $valor < 0) {
                return [[], [], 'Cada concepto necesita un nombre, una cantidad mayor a 0 y un valor válido.'];
            }

            $conceptos[] = [
                'concepto' => $nombre,
                'cantidad' => (int) $cantidad,
                'valor' => (float) $valor,
            ];
        }

        if (empty($conceptos) && $valorAdicional <= 0) {
            return [[], [], 'Agrega al menos un concepto o un concepto adicional con valor.'];
        }

        $subtotalConceptos = array_sum(array_map(
            static fn (array $c): float => $c['cantidad'] * $c['valor'],
            $conceptos
        ));
        $valorTotal = $subtotalConceptos + $valorAdicional;

        $cabecera = [
            'anio_presupuestal_id' => $anioPresupuestalId,
            'autogestion_id' => $autogestionId,
            'dependencia' => $dependencia,
            'concepto_adicional' => $conceptoAdicional,
            'valor_adicional' => $valorAdicional,
            'valor_total' => $valorTotal,
        ];

        return [$cabecera, $conceptos, ''];
    }

    private function guardarIngreso(): array
    {
        [$cabecera, $conceptos, $error] = $this->validarDatosIngreso();

        if ($error !== '') {
            return [$error, ''];
        }

        try {
            $ingresoId = $this->modeloIngreso->crear($cabecera, $conceptos);
        } catch (PDOException $excepcion) {
            return ['No se pudo registrar el ingreso. Verifica el año presupuestal seleccionado.', ''];
        }

        $this->generarEgresosAutomaticos($ingresoId, $cabecera['anio_presupuestal_id'], $cabecera['autogestion_id'], $cabecera['dependencia']);

        return ['', 'Ingreso registrado correctamente.'];
    }

    private function actualizarIngreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloIngreso->obtenerPorId($id) : null;

        if ($existente === null) {
            return ['El ingreso que intentas editar no existe.', ''];
        }

        [$cabecera, $conceptos, $error] = $this->validarDatosIngreso();

        if ($error !== '') {
            return [$error, ''];
        }

        try {
            $this->modeloIngreso->actualizar($id, $cabecera, $conceptos);
        } catch (PDOException $excepcion) {
            return ['No se pudo actualizar el ingreso. Verifica el año presupuestal seleccionado.', ''];
        }

        $this->generarEgresosAutomaticos($id, $cabecera['anio_presupuestal_id'], $cabecera['autogestion_id'], $cabecera['dependencia']);

        (new PeticionArchivada())->sincronizarDesdeOrigen('ingreso_extension', $id, $cabecera['valor_total'], $cabecera['dependencia']);

        $destino = !empty($_POST['volver'])
            ? $_POST['volver']
            : 'index.php?ruta=extension&tab=ingresos&anio_id=' . $cabecera['anio_presupuestal_id'] . '&autogestion_id=' . $cabecera['autogestion_id'];
        header('Location: ' . $destino);
        exit;
    }

    private function eliminarIngreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloIngreso->obtenerPorId($id) : null;

        if ($existente === null) {
            return ['El ingreso que intentas eliminar no existe.', ''];
        }

        $this->modeloIngreso->eliminar($id);
        $this->generarEgresosAutomaticos(
            null,
            (int) $existente['anio_presupuestal_id'],
            (int) $existente['autogestion_id'],
            (string) $existente['dependencia']
        );

        return ['', 'Ingreso eliminado correctamente.'];
    }

    private function eliminarSeleccionados(string $tab): array
    {
        $ids = array_map('intval', $_POST['id'] ?? []);
        $eliminados = 0;

        foreach ($ids as $id) {
            if ($id <= 0) {
                continue;
            }

            if ($tab === 'egresos') {
                $existente = $this->modeloGasto->obtenerPorId($id);

                if ($existente !== null && $existente['tipo_automatico'] === null) {
                    $this->modeloGasto->eliminar($id);
                    $eliminados++;
                }
            } else {
                $existente = $this->modeloIngreso->obtenerPorId($id);

                if ($existente !== null) {
                    $this->modeloIngreso->eliminar($id);
                    $this->generarEgresosAutomaticos(
                        null,
                        (int) $existente['anio_presupuestal_id'],
                        (int) $existente['autogestion_id'],
                        (string) $existente['dependencia']
                    );
                    $eliminados++;
                }
            }
        }

        if ($eliminados === 0) {
            return ['No se eliminó ningún elemento.', ''];
        }

        return ['', 'Se eliminaron ' . $eliminados . ' elemento(s).'];
    }

    private function duplicarSeleccionados(string $tab): array
    {
        $ids = array_map('intval', $_POST['id'] ?? []);
        $db = Conexion::obtener();
        $duplicados = 0;

        foreach ($ids as $id) {
            if ($id <= 0) {
                continue;
            }

            if ($tab === 'egresos') {
                $existente = $this->modeloGasto->obtenerPorId($id);

                if ($existente !== null && $existente['tipo_automatico'] === null && DuplicadorFilas::duplicarFila($db, 'gastos_extension', $id) !== null) {
                    $duplicados++;
                }
            } else {
                $nuevoId = DuplicadorFilas::duplicarFila($db, 'ingresos_extension', $id);

                if ($nuevoId !== null) {
                    DuplicadorFilas::duplicarFilasHijo($db, 'ingresos_extension_conceptos', 'ingreso_id', $id, $nuevoId);
                    $duplicados++;

                    $nuevo = $this->modeloIngreso->obtenerPorId($nuevoId);
                    if ($nuevo !== null) {
                        $this->generarEgresosAutomaticos(
                            null,
                            (int) $nuevo['anio_presupuestal_id'],
                            (int) $nuevo['autogestion_id'],
                            (string) $nuevo['dependencia']
                        );
                    }
                }
            }
        }

        if ($duplicados === 0) {
            return ['No se duplicó ningún elemento.', ''];
        }

        return ['', 'Se duplicaron ' . $duplicados . ' elemento(s).'];
    }

    private function generarEgresosAutomaticos(?int $ingresoId, int $anioPresupuestalId, int $autogestionId, string $dependencia): void
    {
        $porcentajes = $this->modeloPorcentaje->obtenerPorModulo('extension');
        $totalIngresos = $this->modeloIngreso->obtenerTotalPorAnioYAutogestion($anioPresupuestalId, $autogestionId);

        $lineas = [];

        if ($porcentajes['excedentes'] !== null) {
            $lineas['excedentes'] = ['porcentaje' => (float) $porcentajes['excedentes'], 'etiqueta' => 'Excedentes nivel central'];
        }

        $this->modeloGasto->eliminarAutomaticosDistintosDe($anioPresupuestalId, $autogestionId, array_keys($lineas));

        foreach ($lineas as $tipo => $info) {
            $valor = round($totalIngresos * $info['porcentaje'] / 100, 2);
            $porcentajeTexto = rtrim(rtrim(number_format($info['porcentaje'], 2), '0'), '.');

            $categoria = $info['etiqueta'] . ' (' . $porcentajeTexto . '%)';

            $datos = [
                'sede_id' => self::AUTOMATICO_SEDE_ID,
                'anio_presupuestal_id' => $anioPresupuestalId,
                'categoria' => $categoria,
                'dependencia' => $dependencia,
                'linea_id' => self::AUTOMATICO_LINEA_ID,
                'motor_id' => self::AUTOMATICO_MOTOR_ID,
                'proyecto_id' => self::AUTOMATICO_PROYECTO_ID,
                'objeto_proyecto_paa' => self::AUTOMATICO_OBJETO_PROYECTO_PAA,
                'actividad' => self::AUTOMATICO_ACTIVIDAD,
                'rubro_texto' => self::AUTOMATICO_RUBRO_TEXTO,
                'autogestion_id' => $autogestionId,
                'ingreso_id' => $ingresoId,
                'tipo_automatico' => $tipo,
                'insumo' => self::AUTOMATICO_INSUMO,
                'cantidad' => 1,
                'costo_unitario' => $valor,
                'valor_total' => $valor,
                'meses' => (string) self::AUTOMATICO_MES,
            ];

            $existente = $this->modeloGasto->obtenerAutomaticoPorTipo($anioPresupuestalId, $autogestionId, $tipo);

            if ($existente !== null) {
                $this->modeloGasto->actualizarAutomatico((int) $existente['id'], $datos);
            } else {
                $this->modeloGasto->crearAutomatico($datos);
            }
        }
    }
}
