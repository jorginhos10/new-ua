<?php

require_once __DIR__ . '/../config/conexion.php';

class Rubro
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Conexion::obtener();
    }

    public function obtenerTodos(): array
    {
        $consulta = $this->db->query('SELECT id, codigo, descripcion, estado, creado_en FROM rubros ORDER BY codigo');

        return $consulta->fetchAll();
    }

    public function obtenerActivos(): array
    {
        $consulta = $this->db->query(
            "SELECT id, codigo, descripcion FROM rubros WHERE estado = 'activo' ORDER BY descripcion"
        );

        return $consulta->fetchAll();
    }

    public function existeCodigo(string $codigo): bool
    {
        $consulta = $this->db->prepare('SELECT id FROM rubros WHERE codigo = :codigo LIMIT 1');
        $consulta->execute(['codigo' => $codigo]);

        return $consulta->fetch() !== false;
    }

    public function crear(string $codigo, string $descripcion): bool
    {
        $consulta = $this->db->prepare(
            'INSERT INTO rubros (codigo, descripcion) VALUES (:codigo, :descripcion)'
        );

        return $consulta->execute(['codigo' => $codigo, 'descripcion' => $descripcion]);
    }

    public function cambiarEstado(int $id): bool
    {
        $consulta = $this->db->prepare(
            "UPDATE rubros SET estado = IF(estado = 'activo', 'inactivo', 'activo') WHERE id = :id"
        );

        return $consulta->execute(['id' => $id]);
    }
}
