<?php

require_once __DIR__ . '/../config/conexion.php';

class Proyecto
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Conexion::obtener();
    }

    public function obtenerTodos(): array
    {
        $consulta = $this->db->query(
            'SELECT p.id, p.codigo, p.nombre, p.motor_id, p.creado_en,
                    m.codigo AS motor_codigo, m.nombre AS motor_nombre,
                    l.codigo AS linea_codigo, l.nombre AS linea_nombre
             FROM proyectos p
             JOIN motores m ON m.id = p.motor_id
             JOIN lineas l ON l.id = m.linea_id
             ORDER BY p.codigo'
        );

        return $consulta->fetchAll();
    }

    public function crear(string $codigo, string $nombre, int $motorId): bool
    {
        $consulta = $this->db->prepare(
            'INSERT INTO proyectos (codigo, nombre, motor_id) VALUES (:codigo, :nombre, :motor_id)'
        );

        return $consulta->execute(['codigo' => $codigo, 'nombre' => $nombre, 'motor_id' => $motorId]);
    }
}
