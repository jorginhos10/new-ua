<?php $tituloPagina = 'Mensajes'; require __DIR__ . '/../parciales/encabezado.php'; ?>

    <div class="tarjeta">
        <div class="cabecera-modulo">
            <h1>Mensajes</h1>
            <button type="button" id="boton-abrir-modal-mensaje" class="boton-agregar">+ Redactar</button>
        </div>

        <?php if (!empty($error)): ?>
            <p class="mensaje-error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if (!empty($exito)): ?>
            <p class="mensaje-exito"><?= htmlspecialchars($exito) ?></p>
        <?php endif; ?>

        <div class="pestanas">
            <a href="index.php?ruta=mensajes&tab=recibidos" class="pestana<?= $tab === 'recibidos' ? ' activa' : '' ?>">Recibidos</a>
            <a href="index.php?ruta=mensajes&tab=enviados" class="pestana<?= $tab === 'enviados' ? ' activa' : '' ?>">Enviados</a>
        </div>

        <?php $listaActual = $tab === 'enviados' ? $enviados : $recibidos; ?>
        <div class="tabla-scroll">
            <table class="tabla-usuarios">
                <thead>
                    <tr>
                        <?php if ($tab === 'enviados'): ?>
                        <th>Para</th>
                        <?php else: ?>
                        <th>De</th>
                        <?php endif; ?>
                        <th>Asunto</th>
                        <th>Fecha</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($listaActual as $mensajeFila): ?>
                    <tr class="fila-mensaje<?= $tab === 'recibidos' && (int) $mensajeFila['leido'] === 0 ? ' fila-no-leida' : '' ?>" data-mensaje-id="<?= (int) $mensajeFila['id'] ?>">
                        <td><?= htmlspecialchars($tab === 'enviados' ? $mensajeFila['destinatario_nombre'] : $mensajeFila['remitente_nombre']) ?></td>
                        <td>
                            <button
                                type="button"
                                class="enlace-asunto-mensaje boton-ver-mensaje"
                                data-id="<?= (int) $mensajeFila['id'] ?>"
                                data-asunto="<?= htmlspecialchars($mensajeFila['asunto']) ?>"
                                data-cuerpo="<?= htmlspecialchars($mensajeFila['cuerpo']) ?>"
                                data-remitente="<?= htmlspecialchars($tab === 'enviados' ? $nombreActual : $mensajeFila['remitente_nombre']) ?>"
                                data-destinatario="<?= htmlspecialchars($tab === 'enviados' ? $mensajeFila['destinatario_nombre'] : $nombreActual) ?>"
                                data-fecha="<?= htmlspecialchars($mensajeFila['creado_en']) ?>"
                                data-leido="<?= $tab === 'enviados' ? 1 : (int) $mensajeFila['leido'] ?>"
                            ><?= htmlspecialchars($mensajeFila['asunto']) ?></button>
                        </td>
                        <td class="texto-atenuado"><?= htmlspecialchars($mensajeFila['creado_en']) ?></td>
                        <td class="celda-acciones">
                            <div class="acciones-fila">
                                <form method="POST" action="index.php?ruta=mensajes">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <input type="hidden" name="id" value="<?= (int) $mensajeFila['id'] ?>">
                                    <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">
                                    <button type="submit" class="boton-accion boton-accion-eliminar">Eliminar</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($listaActual)): ?>
                    <tr>
                        <td colspan="4">No hay mensajes.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="modal-mensaje" class="modal-fondo">
        <div class="modal-caja">
            <div class="modal-cabecera">
                <h2>Redactar mensaje</h2>
                <button type="button" id="boton-cerrar-modal-mensaje" class="modal-cerrar" aria-label="Cerrar">&times;</button>
            </div>

            <form method="POST" action="index.php?ruta=mensajes&tab=enviados" class="form-necesidad">
                <div class="campo campo-ancho">
                    <label for="destinatario_id">Para *</label>
                    <select id="destinatario_id" name="destinatario_id" required>
                        <option value="">Selecciona un destinatario</option>
                        <?php foreach ($destinatarios as $destinatario): ?>
                        <option value="<?= (int) $destinatario['id'] ?>"><?= htmlspecialchars($destinatario['nombre']) ?> (<?= htmlspecialchars($destinatario['correo']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo campo-ancho">
                    <label for="asunto">Asunto *</label>
                    <input type="text" id="asunto" name="asunto" required>
                </div>

                <div class="campo campo-ancho">
                    <label for="cuerpo">Mensaje *</label>
                    <textarea id="cuerpo" name="cuerpo" rows="6" required></textarea>
                </div>

                <button type="submit" class="boton-enviar">Enviar</button>
            </form>
        </div>
    </div>

<?php require __DIR__ . '/../parciales/pie.php'; ?>
