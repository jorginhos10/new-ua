<?php
$tituloPagina = 'Extensión';
$nombresMeses = [
    1 => 'Ene', 2 => 'Feb', 3 => 'Mar', 4 => 'Abr',
    5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Ago',
    9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dic',
];
$nombresMesesCompletos = [
    1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
    5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
    9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre',
];
$catalogosListosEgreso = !empty($sedes) && !empty($lineas) && !empty($motores) && !empty($proyectos) && !empty($rubros) && !empty($autogestionItems) && !empty($aniosActivos);
$catalogosListosIngreso = !empty($autogestionItems) && !empty($aniosActivos);
$catalogosListos = $tab === 'ingresos' ? $catalogosListosIngreso : $catalogosListosEgreso;
require __DIR__ . '/../parciales/encabezado.php';
?>

    <div class="tarjeta">
        <div class="cabecera-modulo">
            <div class="cabecera-modulo-titulo">
                <h1>Extensión</h1>
                <?php if (!empty($autogestionItems)): ?>
                <select class="selector-autogestion-item" onchange="if (this.value) { window.location.href = this.value; }">
                    <?php foreach ($autogestionItems as $itemAutogestion): ?>
                    <option
                        value="index.php?ruta=extension&tab=<?= htmlspecialchars($tab) ?>&autogestion_id=<?= (int) $itemAutogestion['id'] ?>&anio_id=<?= (int) $anioSeleccionadoId ?>"
                        <?= $autogestionSeleccionadoId === (int) $itemAutogestion['id'] ? 'selected' : '' ?>
                    ><?= htmlspecialchars($itemAutogestion['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php endif; ?>
            </div>
            <?php if ($catalogosListos): ?>
            <button type="button" id="boton-abrir-modal-gasto" class="boton-agregar">+ Agregar <?= $tab === 'ingresos' ? 'ingreso' : 'egreso' ?></button>
            <?php endif; ?>
        </div>

        <div class="pestanas">
            <a href="index.php?ruta=extension&tab=ingresos" class="pestana<?= $tab === 'ingresos' ? ' activa' : '' ?>">Ingresos</a>
            <a href="index.php?ruta=extension&tab=egresos" class="pestana<?= $tab === 'egresos' ? ' activa' : '' ?>">Egresos</a>
            <?php if ($tab === 'ingresos'): ?>
            <span class="total-pestanas">Total ingresos: <?= number_format($totalGastado, 2) ?></span>
            <?php endif; ?>
        </div>

        <?php if (!empty($error)): ?>
            <p class="mensaje-error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if (!empty($exito)): ?>
            <p class="mensaje-exito"><?= htmlspecialchars($exito) ?></p>
        <?php endif; ?>

        <?php if ($tab === 'egresos'): ?>
            <?php if (empty($sedes)): ?>
                <p class="mensaje-error">Primero debes crear al menos una sede en <a href="index.php?ruta=sedes">Configuraciones &gt; Sedes</a>.</p>
            <?php elseif (empty($lineas)): ?>
                <p class="mensaje-error">Primero debes crear al menos una línea en <a href="index.php?ruta=lineas">Configuraciones &gt; Línea</a>.</p>
            <?php elseif (empty($motores)): ?>
                <p class="mensaje-error">Primero debes crear al menos un motor en <a href="index.php?ruta=motores">Configuraciones &gt; Motor</a>.</p>
            <?php elseif (empty($proyectos)): ?>
                <p class="mensaje-error">Primero debes crear al menos un proyecto en <a href="index.php?ruta=proyectos">Configuraciones &gt; Proyecto</a>.</p>
            <?php elseif (empty($rubros)): ?>
                <p class="mensaje-error">Primero debes crear al menos un rubro en <a href="index.php?ruta=rubros">Configuraciones &gt; Rubros</a>.</p>
            <?php elseif (empty($autogestionItems)): ?>
                <p class="mensaje-error">Primero debes crear al menos un ítem en <a href="index.php?ruta=autogestion">Configuraciones &gt; Autogestión</a>.</p>
            <?php elseif (empty($aniosActivos)): ?>
                <p class="mensaje-error">Primero debes crear un año presupuestal activo en <a href="index.php?ruta=anios-presupuestales">Configuraciones &gt; Año presupuestal</a>.</p>
            <?php endif; ?>
        <?php elseif (empty($autogestionItems)): ?>
            <p class="mensaje-error">Primero debes crear al menos un ítem en <a href="index.php?ruta=autogestion">Configuraciones &gt; Autogestión</a>.</p>
        <?php elseif (empty($aniosActivos)): ?>
            <p class="mensaje-error">Primero debes crear un año presupuestal activo en <a href="index.php?ruta=anios-presupuestales">Configuraciones &gt; Año presupuestal</a>.</p>
        <?php endif; ?>

        <form method="GET" action="index.php" id="form-filtros" class="form-filtro-anio">
            <input type="hidden" name="ruta" value="extension">
            <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">
            <?php if (count($aniosActivos) >= 2): ?>
            <label for="anio_id_filtro">Año presupuestal</label>
            <select id="anio_id_filtro" name="anio_id" onchange="this.form.submit()">
                <?php foreach ($aniosActivos as $anioFila): ?>
                <option value="<?= (int) $anioFila['id'] ?>" <?= $anioSeleccionadoId === (int) $anioFila['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars((string) $anioFila['anio']) ?>
                </option>
                <?php endforeach; ?>
            </select>
            <?php elseif ($anioSeleccionadoId > 0): ?>
            <input type="hidden" name="anio_id" value="<?= $anioSeleccionadoId ?>">
            <?php endif; ?>
        </form>

        <?php if ($tab === 'egresos' && $anioSeleccionado): ?>
            <div class="progreso-presupuesto">
                <div class="progreso-presupuesto-info">
                    <span class="progreso-presupuesto-porcentaje">
                        <?php if ($presupuestoAnio > 0): ?>
                            <?= number_format($porcentajeGastado, 1) ?>% de los ingresos <?= (int) $anioSeleccionado['anio'] ?> asignados
                            (<?= number_format($totalEjecutado, 2) ?> / <?= number_format($presupuestoAnio, 2) ?>)
                        <?php else: ?>
                            Este ítem todavía no tiene ingresos registrados: no se pueden agregar egresos hasta que tenga.
                        <?php endif; ?>
                    </span>
                    <span class="progreso-presupuesto-dias">Día <?= $diaActual ?>/<?= $totalDiasAnio ?></span>
                </div>
                <div class="barra-progreso">
                    <div class="barra-progreso-segmento costos" style="width: <?= number_format($pctCostos, 2, '.', '') ?>%;"></div>
                    <div class="barra-progreso-segmento inversion" style="width: <?= number_format($pctInversion, 2, '.', '') ?>%;"></div>
                    <div class="barra-progreso-segmento excedentes" style="width: <?= number_format($pctExcedentes, 2, '.', '') ?>%;"></div>
                </div>
                <div class="progreso-presupuesto-leyenda">
                    <span><span class="punto costos"></span>Costos: <?= number_format($totalCostos, 2) ?></span>
                    <span><span class="punto inversion"></span>Inversión: <?= number_format($totalInversion, 2) ?></span>
                    <span><span class="punto excedentes"></span>Excedentes: <?= number_format($totalExcedentes, 2) ?></span>
                </div>
            </div>
        <?php elseif ($tab === 'ingresos' && $anioSeleccionado): ?>
            <div class="resumen-egresos">
                <span class="resumen-egresos-titulo">
                    <?php if ($presupuestoAnio > 0): ?>
                        <?= number_format($porcentajeGastado, 1) ?>% de los ingresos <?= (int) $anioSeleccionado['anio'] ?> asignados
                        (<?= number_format($totalEjecutado, 2) ?> / <?= number_format($presupuestoAnio, 2) ?>)
                    <?php else: ?>
                        Este ítem todavía no tiene ingresos registrados.
                    <?php endif; ?>
                </span>
                <div class="progreso-presupuesto-leyenda">
                    <span><span class="punto costos"></span>Costos: <?= number_format($totalCostos, 2) ?></span>
                    <span><span class="punto inversion"></span>Inversión: <?= number_format($totalInversion, 2) ?></span>
                    <span><span class="punto excedentes"></span>Excedentes: <?= number_format($totalExcedentes, 2) ?></span>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($tab === 'egresos'): ?>
        <div class="tabla-scroll">
            <table class="tabla-usuarios">
                <thead>
                    <tr>
                        <th>Acciones</th>
                        <th>Categoría</th>
                        <th>Sede</th>
                        <th>Dependencia</th>
                        <th>Línea estratégica</th>
                        <th>Motor de desarrollo</th>
                        <th>Proyecto PDI</th>
                        <th>Objeto/Proyecto (PAA)</th>
                        <th>Actividad</th>
                        <th>Rubro</th>
                        <th>Insumo</th>
                        <th>Cantidad</th>
                        <th>Costo unitario</th>
                        <th>Valor total</th>
                        <th>Meses</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($gastos as $gasto): ?>
                    <?php
                    $mesesGasto = $gasto['meses'] !== ''
                        ? array_map(static fn ($mes) => $nombresMeses[(int) $mes] ?? $mes, explode(',', $gasto['meses']))
                        : [];
                    ?>
                    <tr>
                        <td class="celda-acciones">
                            <?php if ($gasto['tipo_automatico'] === null): ?>
                            <div class="acciones-fila">
                                <button
                                    type="button"
                                    class="boton-accion boton-accion-editar boton-editar-egreso"
                                    data-gasto="<?= htmlspecialchars(json_encode($gasto)) ?>"
                                >Editar</button>
                                <form method="POST" action="index.php?ruta=extension&tab=egresos&anio_id=<?= (int) $anioSeleccionadoId ?>&autogestion_id=<?= (int) $autogestionSeleccionadoId ?>" class="form-eliminar-egreso">
                                    <input type="hidden" name="tab" value="egresos">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <input type="hidden" name="id" value="<?= (int) $gasto['id'] ?>">
                                    <button type="submit" class="boton-accion boton-accion-eliminar">Eliminar</button>
                                </form>
                            </div>
                            <?php else: ?>
                            <span class="texto-atenuado">Automático</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($gasto['categoria']) ?></td>
                        <td><?= htmlspecialchars($gasto['sede_codigo'] . ' - ' . $gasto['sede_nombre']) ?></td>
                        <td><?= htmlspecialchars($gasto['dependencia']) ?></td>
                        <td><?= htmlspecialchars($gasto['linea_codigo'] . ' - ' . $gasto['linea_nombre']) ?></td>
                        <td><?= htmlspecialchars($gasto['motor_codigo'] . ' - ' . $gasto['motor_nombre']) ?></td>
                        <td><?= htmlspecialchars($gasto['proyecto_codigo'] . ' - ' . $gasto['proyecto_nombre']) ?></td>
                        <td><?= htmlspecialchars($gasto['objeto_proyecto_paa']) ?></td>
                        <td><?= htmlspecialchars($gasto['actividad']) ?></td>
                        <td><?= $gasto['rubro_id'] !== null ? htmlspecialchars($gasto['rubro_codigo'] . ' - ' . $gasto['rubro_descripcion']) : htmlspecialchars((string) $gasto['rubro_texto']) ?></td>
                        <td><?= htmlspecialchars($gasto['insumo']) ?></td>
                        <td><?= (int) $gasto['cantidad'] ?></td>
                        <td><?= number_format((float) $gasto['costo_unitario'], 2) ?></td>
                        <td><?= number_format((float) $gasto['valor_total'], 2) ?></td>
                        <td><?= htmlspecialchars(implode(', ', $mesesGasto)) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($gastos)): ?>
                    <tr>
                        <td colspan="15">No hay egresos registrados.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="tabla-scroll">
            <table class="tabla-usuarios">
                <thead>
                    <tr>
                        <th>Acciones</th>
                        <th>Dependencia</th>
                        <th>Concepto</th>
                        <th>Valor</th>
                        <th>Concepto adicional</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($gastos as $ingreso): ?>
                    <tr>
                        <td class="celda-acciones">
                            <div class="acciones-fila">
                                <button
                                    type="button"
                                    class="boton-accion boton-accion-editar boton-editar-ingreso"
                                    data-ingreso="<?= htmlspecialchars(json_encode($ingreso)) ?>"
                                >Editar</button>
                                <form method="POST" action="index.php?ruta=extension&tab=ingresos&anio_id=<?= (int) $anioSeleccionadoId ?>&autogestion_id=<?= (int) $autogestionSeleccionadoId ?>" class="form-eliminar-ingreso">
                                    <input type="hidden" name="tab" value="ingresos">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <input type="hidden" name="id" value="<?= (int) $ingreso['id'] ?>">
                                    <button type="submit" class="boton-accion boton-accion-eliminar">Eliminar</button>
                                </form>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($ingreso['dependencia']) ?></td>
                        <td>
                            <div class="lista-conceptos-celda">
                                <?php foreach ($ingreso['conceptos'] as $concepto): ?>
                                <span><?= htmlspecialchars($concepto['concepto']) ?> (×<?= (int) $concepto['cantidad'] ?>)</span>
                                <?php endforeach; ?>
                                <?php if (empty($ingreso['conceptos'])): ?>
                                <span class="texto-atenuado">Sin conceptos.</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <div class="lista-conceptos-celda">
                                <?php foreach ($ingreso['conceptos'] as $concepto): ?>
                                <span><?= number_format((float) $concepto['valor'], 2) ?></span>
                                <?php endforeach; ?>
                                <?php if (empty($ingreso['conceptos'])): ?>
                                <span class="texto-atenuado">—</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td><?= $ingreso['concepto_adicional'] !== '' ? htmlspecialchars($ingreso['concepto_adicional']) . ' (' . number_format((float) $ingreso['valor_adicional'], 2) . ')' : '—' ?></td>
                        <td><?= number_format((float) $ingreso['valor_total'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($gastos)): ?>
                    <tr>
                        <td colspan="6">No hay ingresos registrados.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($catalogosListos): ?>
    <div id="modal-gasto" class="modal-fondo<?= !empty($error) ? ' abierto' : '' ?>">
        <div class="modal-caja">
            <div class="modal-cabecera">
                <h2>Registrar <?= $tab === 'ingresos' ? 'ingreso' : 'egreso' ?></h2>
                <button type="button" id="boton-cerrar-modal-gasto" class="modal-cerrar" aria-label="Cerrar">&times;</button>
            </div>

            <?php if ($tab === 'egresos'): ?>
            <form method="POST" action="index.php?ruta=extension&tab=egresos" id="form-egreso" class="form-necesidad">
                <input type="hidden" name="tab" value="egresos">
                <input type="hidden" name="autogestion_id" value="<?= $autogestionSeleccionadoId ?>">
                <div class="campo">
                    <label for="anio_presupuestal_id">Año presupuestal *</label>
                    <select id="anio_presupuestal_id" name="anio_presupuestal_id" required>
                        <option value="">Selecciona un año</option>
                        <?php foreach ($aniosActivos as $anioOpcion): ?>
                        <option value="<?= (int) $anioOpcion['id'] ?>" <?= $anioSeleccionadoId === (int) $anioOpcion['id'] ? 'selected' : '' ?>><?= htmlspecialchars((string) $anioOpcion['anio']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="categoria">Categoría *</label>
                    <select id="categoria" name="categoria" required>
                        <option value="">Selecciona una categoría</option>
                        <?php foreach ($categoriasEgreso as $categoriaOpcion): ?>
                        <option value="<?= htmlspecialchars($categoriaOpcion) ?>"><?= htmlspecialchars($categoriaOpcion) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="sede_id">Sede *</label>
                    <select id="sede_id" name="sede_id" required>
                        <option value="">Selecciona una sede</option>
                        <?php foreach ($sedes as $sede): ?>
                        <option value="<?= (int) $sede['id'] ?>"><?= htmlspecialchars($sede['codigo'] . ' - ' . $sede['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="dependencia">Dependencia *</label>
                    <?php if (!$tieneHijas && $dependenciaPorDefecto !== null): ?>
                    <select disabled>
                        <option selected><?= htmlspecialchars($dependenciaPorDefecto) ?></option>
                    </select>
                    <input type="hidden" name="dependencia" id="dependencia" value="<?= htmlspecialchars($dependenciaPorDefecto) ?>">
                    <?php else: ?>
                    <select id="dependencia" name="dependencia" required>
                        <option value="">Selecciona una dependencia</option>
                        <?php foreach ($dependenciasSugeridas as $dependenciaSugerida): ?>
                        <option value="<?= htmlspecialchars($dependenciaSugerida) ?>" <?= $dependenciaSugerida === $dependenciaPorDefecto ? 'selected' : '' ?>><?= htmlspecialchars($dependenciaSugerida) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                </div>

                <div class="campo">
                    <label for="linea_id">Línea estratégica *</label>
                    <select id="linea_id" name="linea_id" required>
                        <option value="">Selecciona una línea</option>
                        <?php foreach ($lineas as $linea): ?>
                        <option value="<?= (int) $linea['id'] ?>"><?= htmlspecialchars($linea['codigo'] . ' - ' . $linea['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="motor_id">Motor de desarrollo *</label>
                    <select id="motor_id" name="motor_id" required>
                        <option value="">Selecciona una línea primero</option>
                        <?php foreach ($motores as $motor): ?>
                        <option value="<?= (int) $motor['id'] ?>" data-linea="<?= (int) $motor['linea_id'] ?>"><?= htmlspecialchars($motor['codigo'] . ' - ' . $motor['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="proyecto_id">Proyecto PDI *</label>
                    <select id="proyecto_id" name="proyecto_id" required>
                        <option value="">Selecciona un motor primero</option>
                        <?php foreach ($proyectos as $proyecto): ?>
                        <option value="<?= (int) $proyecto['id'] ?>" data-motor="<?= (int) $proyecto['motor_id'] ?>"><?= htmlspecialchars($proyecto['codigo'] . ' - ' . $proyecto['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="objeto_proyecto_paa">Objeto/Proyecto (PAA)</label>
                    <input type="text" id="objeto_proyecto_paa" name="objeto_proyecto_paa" placeholder="Diligenciar">
                </div>

                <div class="campo campo-ancho">
                    <label for="actividad">Actividad *</label>
                    <input type="text" id="actividad" name="actividad" placeholder="Diligenciar" required>
                </div>

                <div class="campo campo-ancho">
                    <label for="rubro_buscador">Rubro *</label>
                    <div class="selector-buscable" id="selector-rubro">
                        <input type="text" id="rubro_buscador" class="selector-buscable-input" placeholder="Buscar rubro..." autocomplete="off">
                        <input type="hidden" name="rubro_id" id="rubro_id">
                        <div class="selector-buscable-lista" id="rubro_lista">
                            <?php foreach ($rubros as $rubro): ?>
                            <div class="selector-buscable-opcion" data-id="<?= (int) $rubro['id'] ?>" data-texto="<?= htmlspecialchars($rubro['codigo'] . ' - ' . $rubro['descripcion']) ?>">
                                <?= htmlspecialchars($rubro['codigo'] . ' - ' . $rubro['descripcion']) ?>
                            </div>
                            <?php endforeach; ?>
                            <div class="selector-buscable-vacio">Sin resultados.</div>
                        </div>
                    </div>
                </div>

                <div class="campo">
                    <label for="insumo">Insumo *</label>
                    <input type="text" id="insumo" name="insumo" placeholder="Diligenciar" required>
                </div>

                <div class="campo">
                    <label for="cantidad">Cantidad *</label>
                    <input type="number" id="cantidad" name="cantidad" min="1" step="1" required>
                </div>

                <div class="campo">
                    <label for="costo_unitario">Costo unitario *</label>
                    <input type="number" id="costo_unitario" name="costo_unitario" min="0" step="0.01" required>
                </div>

                <div class="campo campo-ancho">
                    <label>Meses de ejecución *</label>
                    <div class="calendario-meses-envoltorio">
                        <div class="calendario-meses">
                            <div class="calendario-meses-cabecera">Calendario</div>
                            <div class="calendario-meses-grilla">
                                <?php foreach ($nombresMesesCompletos as $numero => $nombre): ?>
                                <label class="mes-celda">
                                    <input type="checkbox" name="meses[]" value="<?= $numero ?>">
                                    <span><?= htmlspecialchars($nombre) ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="resumen-meses">
                            <h3>Distribución del presupuesto</h3>
                            <ul id="lista-meses-seleccionados" class="lista-meses-seleccionados">
                                <li class="lista-meses-vacio">Selecciona los meses de ejecución.</li>
                            </ul>
                            <div class="resumen-meses-total">
                                <span>Total</span>
                                <span id="resumen-meses-total-valor">$0.00</span>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="boton-enviar">Registrar egreso</button>
            </form>
            <?php else: ?>
            <form method="POST" action="index.php?ruta=extension&tab=ingresos" class="form-necesidad">
                <input type="hidden" name="tab" value="ingresos">
                <input type="hidden" name="autogestion_id" value="<?= $autogestionSeleccionadoId ?>">
                <div class="campo">
                    <label for="anio_presupuestal_id">Año presupuestal *</label>
                    <select id="anio_presupuestal_id" name="anio_presupuestal_id" required>
                        <option value="">Selecciona un año</option>
                        <?php foreach ($aniosActivos as $anioOpcion): ?>
                        <option value="<?= (int) $anioOpcion['id'] ?>" <?= $anioSeleccionadoId === (int) $anioOpcion['id'] ? 'selected' : '' ?>><?= htmlspecialchars((string) $anioOpcion['anio']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="dependencia_ingreso">Dependencia *</label>
                    <?php if (!$tieneHijas && $dependenciaPorDefecto !== null): ?>
                    <select disabled>
                        <option selected><?= htmlspecialchars($dependenciaPorDefecto) ?></option>
                    </select>
                    <input type="hidden" name="dependencia" id="dependencia_ingreso" value="<?= htmlspecialchars($dependenciaPorDefecto) ?>">
                    <?php else: ?>
                    <select id="dependencia_ingreso" name="dependencia" required>
                        <option value="">Selecciona una dependencia</option>
                        <?php foreach ($dependenciasSugeridas as $dependenciaSugerida): ?>
                        <option value="<?= htmlspecialchars($dependenciaSugerida) ?>" <?= $dependenciaSugerida === $dependenciaPorDefecto ? 'selected' : '' ?>><?= htmlspecialchars($dependenciaSugerida) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                </div>

                <div class="campo campo-ancho">
                    <label>Conceptos *</label>
                    <div class="filas-conceptos" id="filas-conceptos">
                        <div class="fila-concepto">
                            <div class="campo">
                                <label>Concepto</label>
                                <input type="text" name="concepto[]" placeholder="Ej. Matrícula">
                            </div>
                            <div class="campo">
                                <label>Cantidad</label>
                                <input type="number" name="cantidad_concepto[]" min="1" step="1">
                            </div>
                            <div class="campo">
                                <label>Valor unitario</label>
                                <input type="number" name="valor_concepto[]" min="0" step="0.01">
                            </div>
                            <button type="button" class="boton-quitar-fila" aria-label="Quitar concepto">&times;</button>
                        </div>
                    </div>
                    <button type="button" class="boton-agregar-fila" id="boton-agregar-concepto">+ Agregar concepto</button>
                </div>

                <div class="campo">
                    <label for="concepto_adicional">Concepto adicional</label>
                    <input type="text" id="concepto_adicional" name="concepto_adicional" placeholder="Opcional">
                </div>

                <div class="campo">
                    <label for="valor_adicional">Valor adicional</label>
                    <input type="number" id="valor_adicional" name="valor_adicional" min="0" step="0.01" placeholder="0.00">
                </div>

                <button type="submit" class="boton-enviar">Registrar ingreso</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($catalogosListosEgreso): ?>
    <div id="modal-editar-egreso" class="modal-fondo">
        <div class="modal-caja">
            <div class="modal-cabecera">
                <h2>Editar egreso</h2>
                <button type="button" id="boton-cerrar-modal-editar-egreso" class="modal-cerrar" aria-label="Cerrar">&times;</button>
            </div>

            <form method="POST" action="index.php?ruta=extension&tab=egresos&anio_id=<?= (int) $anioSeleccionadoId ?>&autogestion_id=<?= (int) $autogestionSeleccionadoId ?>" class="form-necesidad">
                <input type="hidden" name="tab" value="egresos">
                <input type="hidden" name="accion" value="actualizar">
                <input type="hidden" name="id" id="editar-egreso-id" value="">
                <input type="hidden" name="autogestion_id" id="editar-egreso-autogestion_id" value="">

                <div class="campo">
                    <label for="editar-egreso-anio_presupuestal_id">Año presupuestal *</label>
                    <select id="editar-egreso-anio_presupuestal_id" name="anio_presupuestal_id" required>
                        <option value="">Selecciona un año</option>
                        <?php foreach ($aniosActivos as $anioOpcion): ?>
                        <option value="<?= (int) $anioOpcion['id'] ?>"><?= htmlspecialchars((string) $anioOpcion['anio']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="editar-egreso-categoria">Categoría *</label>
                    <select id="editar-egreso-categoria" name="categoria" required>
                        <option value="">Selecciona una categoría</option>
                        <?php foreach ($categoriasEgreso as $categoriaOpcion): ?>
                        <option value="<?= htmlspecialchars($categoriaOpcion) ?>"><?= htmlspecialchars($categoriaOpcion) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="editar-egreso-sede_id">Sede *</label>
                    <select id="editar-egreso-sede_id" name="sede_id" required>
                        <option value="">Selecciona una sede</option>
                        <?php foreach ($sedes as $sede): ?>
                        <option value="<?= (int) $sede['id'] ?>"><?= htmlspecialchars($sede['codigo'] . ' - ' . $sede['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="editar-egreso-dependencia">Dependencia *</label>
                    <?php if (!$tieneHijas && $dependenciaPorDefecto !== null): ?>
                    <select disabled>
                        <option selected><?= htmlspecialchars($dependenciaPorDefecto) ?></option>
                    </select>
                    <input type="hidden" name="dependencia" id="editar-egreso-dependencia" value="<?= htmlspecialchars($dependenciaPorDefecto) ?>">
                    <?php else: ?>
                    <select id="editar-egreso-dependencia" name="dependencia" required>
                        <option value="">Selecciona una dependencia</option>
                        <?php foreach ($dependenciasSugeridas as $dependenciaSugerida): ?>
                        <option value="<?= htmlspecialchars($dependenciaSugerida) ?>"><?= htmlspecialchars($dependenciaSugerida) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                </div>

                <div class="campo">
                    <label for="editar-egreso-linea_id">Línea estratégica *</label>
                    <select id="editar-egreso-linea_id" name="linea_id" required>
                        <option value="">Selecciona una línea</option>
                        <?php foreach ($lineas as $linea): ?>
                        <option value="<?= (int) $linea['id'] ?>"><?= htmlspecialchars($linea['codigo'] . ' - ' . $linea['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="editar-egreso-motor_id">Motor de desarrollo *</label>
                    <select id="editar-egreso-motor_id" name="motor_id" required>
                        <option value="">Selecciona un motor</option>
                        <?php foreach ($motores as $motor): ?>
                        <option value="<?= (int) $motor['id'] ?>"><?= htmlspecialchars($motor['codigo'] . ' - ' . $motor['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="editar-egreso-proyecto_id">Proyecto PDI *</label>
                    <select id="editar-egreso-proyecto_id" name="proyecto_id" required>
                        <option value="">Selecciona un proyecto</option>
                        <?php foreach ($proyectos as $proyecto): ?>
                        <option value="<?= (int) $proyecto['id'] ?>"><?= htmlspecialchars($proyecto['codigo'] . ' - ' . $proyecto['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="editar-egreso-objeto_proyecto_paa">Objeto/Proyecto (PAA)</label>
                    <input type="text" id="editar-egreso-objeto_proyecto_paa" name="objeto_proyecto_paa" placeholder="Diligenciar">
                </div>

                <div class="campo campo-ancho">
                    <label for="editar-egreso-actividad">Actividad *</label>
                    <input type="text" id="editar-egreso-actividad" name="actividad" placeholder="Diligenciar" required>
                </div>

                <div class="campo campo-ancho">
                    <label for="editar-egreso-rubro_buscador">Rubro *</label>
                    <div class="selector-buscable" id="editar-egreso-selector-rubro">
                        <input type="text" id="editar-egreso-rubro_buscador" class="selector-buscable-input" placeholder="Buscar rubro..." autocomplete="off">
                        <input type="hidden" name="rubro_id" id="editar-egreso-rubro_id">
                        <div class="selector-buscable-lista" id="editar-egreso-rubro_lista">
                            <?php foreach ($rubros as $rubro): ?>
                            <div class="selector-buscable-opcion" data-id="<?= (int) $rubro['id'] ?>" data-texto="<?= htmlspecialchars($rubro['codigo'] . ' - ' . $rubro['descripcion']) ?>">
                                <?= htmlspecialchars($rubro['codigo'] . ' - ' . $rubro['descripcion']) ?>
                            </div>
                            <?php endforeach; ?>
                            <div class="selector-buscable-vacio">Sin resultados.</div>
                        </div>
                    </div>
                </div>

                <div class="campo">
                    <label for="editar-egreso-insumo">Insumo *</label>
                    <input type="text" id="editar-egreso-insumo" name="insumo" placeholder="Diligenciar" required>
                </div>

                <div class="campo">
                    <label for="editar-egreso-cantidad">Cantidad *</label>
                    <input type="number" id="editar-egreso-cantidad" name="cantidad" min="1" step="1" required>
                </div>

                <div class="campo">
                    <label for="editar-egreso-costo_unitario">Costo unitario *</label>
                    <input type="number" id="editar-egreso-costo_unitario" name="costo_unitario" min="0" step="0.01" required>
                </div>

                <div class="campo campo-ancho">
                    <label>Meses de ejecución *</label>
                    <div class="calendario-meses-envoltorio">
                        <div class="calendario-meses">
                            <div class="calendario-meses-cabecera">Calendario</div>
                            <div class="calendario-meses-grilla">
                                <?php foreach ($nombresMesesCompletos as $numero => $nombre): ?>
                                <label class="mes-celda">
                                    <input type="checkbox" name="meses[]" value="<?= $numero ?>">
                                    <span><?= htmlspecialchars($nombre) ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="resumen-meses">
                            <h3>Distribución del presupuesto</h3>
                            <ul class="lista-meses-seleccionados">
                                <li class="lista-meses-vacio">Selecciona los meses de ejecución.</li>
                            </ul>
                            <div class="resumen-meses-total">
                                <span>Total</span>
                                <span class="resumen-meses-total-valor">$0.00</span>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="boton-enviar">Guardar cambios</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($catalogosListosIngreso): ?>
    <div id="modal-editar-ingreso" class="modal-fondo">
        <div class="modal-caja">
            <div class="modal-cabecera">
                <h2>Editar ingreso</h2>
                <button type="button" id="boton-cerrar-modal-editar-ingreso" class="modal-cerrar" aria-label="Cerrar">&times;</button>
            </div>

            <form method="POST" action="index.php?ruta=extension&tab=ingresos&anio_id=<?= (int) $anioSeleccionadoId ?>&autogestion_id=<?= (int) $autogestionSeleccionadoId ?>" class="form-necesidad">
                <input type="hidden" name="tab" value="ingresos">
                <input type="hidden" name="accion" value="actualizar">
                <input type="hidden" name="id" id="editar-ingreso-id" value="">
                <input type="hidden" name="autogestion_id" id="editar-ingreso-autogestion_id" value="">

                <div class="campo">
                    <label for="editar-ingreso-anio_presupuestal_id">Año presupuestal *</label>
                    <select id="editar-ingreso-anio_presupuestal_id" name="anio_presupuestal_id" required>
                        <option value="">Selecciona un año</option>
                        <?php foreach ($aniosActivos as $anioOpcion): ?>
                        <option value="<?= (int) $anioOpcion['id'] ?>"><?= htmlspecialchars((string) $anioOpcion['anio']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="editar-ingreso-dependencia">Dependencia *</label>
                    <?php if (!$tieneHijas && $dependenciaPorDefecto !== null): ?>
                    <select disabled>
                        <option selected><?= htmlspecialchars($dependenciaPorDefecto) ?></option>
                    </select>
                    <input type="hidden" name="dependencia" id="editar-ingreso-dependencia" value="<?= htmlspecialchars($dependenciaPorDefecto) ?>">
                    <?php else: ?>
                    <select id="editar-ingreso-dependencia" name="dependencia" required>
                        <option value="">Selecciona una dependencia</option>
                        <?php foreach ($dependenciasSugeridas as $dependenciaSugerida): ?>
                        <option value="<?= htmlspecialchars($dependenciaSugerida) ?>"><?= htmlspecialchars($dependenciaSugerida) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                </div>

                <div class="campo campo-ancho">
                    <label>Conceptos *</label>
                    <div class="filas-conceptos" id="editar-filas-conceptos">
                        <div class="fila-concepto">
                            <div class="campo">
                                <label>Concepto</label>
                                <input type="text" name="concepto[]" placeholder="Ej. Matrícula">
                            </div>
                            <div class="campo">
                                <label>Cantidad</label>
                                <input type="number" name="cantidad_concepto[]" min="1" step="1">
                            </div>
                            <div class="campo">
                                <label>Valor unitario</label>
                                <input type="number" name="valor_concepto[]" min="0" step="0.01">
                            </div>
                            <button type="button" class="boton-quitar-fila" aria-label="Quitar concepto">&times;</button>
                        </div>
                    </div>
                    <button type="button" class="boton-agregar-fila">+ Agregar concepto</button>
                </div>

                <div class="campo">
                    <label for="editar-ingreso-concepto_adicional">Concepto adicional</label>
                    <input type="text" id="editar-ingreso-concepto_adicional" name="concepto_adicional" placeholder="Opcional">
                </div>

                <div class="campo">
                    <label for="editar-ingreso-valor_adicional">Valor adicional</label>
                    <input type="number" id="editar-ingreso-valor_adicional" name="valor_adicional" min="0" step="0.01" placeholder="0.00">
                </div>

                <button type="submit" class="boton-enviar">Guardar cambios</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

<?php require __DIR__ . '/../parciales/pie.php'; ?>
