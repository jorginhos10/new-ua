<?php $tituloPagina = 'Proyectos'; require __DIR__ . '/../parciales/encabezado.php'; ?>

    <div class="tarjeta">
        <h1>Proyectos</h1>

        <?php if (!empty($error)): ?>
            <p class="mensaje-error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if (!empty($exito)): ?>
            <p class="mensaje-exito"><?= htmlspecialchars($exito) ?></p>
        <?php endif; ?>

        <?php if (empty($motores)): ?>
            <p class="mensaje-error">Primero debes crear al menos un motor en el módulo Motores.</p>
        <?php else: ?>
            <form method="POST" action="index.php?ruta=proyectos" class="form-agregar">
                <input type="text" name="codigo" placeholder="Código (ej. P1)" maxlength="10" required>
                <input type="text" name="nombre" placeholder="Nombre del proyecto" required>
                <select name="motor_id" required>
                    <option value="">Selecciona un motor</option>
                    <?php foreach ($motores as $motor): ?>
                    <option value="<?= (int) $motor['id'] ?>"><?= htmlspecialchars($motor['codigo'] . ' - ' . $motor['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">Agregar</button>
            </form>
        <?php endif; ?>

        <table class="tabla-usuarios">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Motor</th>
                    <th>Línea</th>
                    <th>Creado</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($proyectos as $proyecto): ?>
                <tr>
                    <td><?= htmlspecialchars($proyecto['codigo']) ?></td>
                    <td><?= htmlspecialchars($proyecto['nombre']) ?></td>
                    <td><?= htmlspecialchars($proyecto['motor_codigo'] . ' - ' . $proyecto['motor_nombre']) ?></td>
                    <td><?= htmlspecialchars($proyecto['linea_codigo'] . ' - ' . $proyecto['linea_nombre']) ?></td>
                    <td><?= htmlspecialchars($proyecto['creado_en']) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($proyectos)): ?>
                <tr>
                    <td colspan="5">No hay proyectos registrados.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php require __DIR__ . '/../parciales/pie.php'; ?>
