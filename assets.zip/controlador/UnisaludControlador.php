<?php

require_once __DIR__ . '/../modelo/GastoUnisalud.php';
require_once __DIR__ . '/../modelo/IngresoUnisalud.php';
require_once __DIR__ . '/../modelo/Linea.php';
require_once __DIR__ . '/../modelo/Motor.php';
require_once __DIR__ . '/../modelo/Proyecto.php';
require_once __DIR__ . '/../modelo/Rubro.php';
require_once __DIR__ . '/../modelo/AnioPresupuestal.php';
require_once __DIR__ . '/../modelo/Sede.php';
require_once __DIR__ . '/../modelo/AutogestionPorcentaje.php';
require_once __DIR__ . '/../modelo/Dependencia.php';
require_once __DIR__ . '/../modelo/Usuario.php';

class UnisaludControlador
{
    private GastoUnisalud $modeloGasto;
    private IngresoUnisalud $modeloIngreso;
    private Linea $modeloLinea;
    private Motor $modeloMotor;
    private Proyecto $modeloProyecto;
    private Rubro $modeloRubro;
    private AnioPresupuestal $modeloAnio;
    private Sede $modeloSede;
    private AutogestionPorcentaje $modeloPorcentaje;
    private Dependencia $modeloDependencia;
    private Usuario $modeloUsuario;

    private const CAMPOS_REQUERIDOS_EGRESO = [
        'sede_id',
        'anio_presupuestal_id',
        'categoria',
        'dependencia',
        'linea_id',
        'motor_id',
        'proyecto_id',
        'actividad',
        'rubro_id',
        'insumo',
        'cantidad',
        'costo_unitario',
    ];

    private const CATEGORIAS_EGRESO = [
        'Gastos',
        'Inversiones',
    ];

    private const AUTOMATICO_SEDE_ID = 1;
    private const AUTOMATICO_LINEA_ID = 5;
    private const AUTOMATICO_MOTOR_ID = 1;
    private const AUTOMATICO_PROYECTO_ID = 1;
    private const AUTOMATICO_RUBRO_TEXTO = 'SERVICIOS DE DISTRIBUCIÓN DE ELECTRICIDAD, GAS Y AGUA (POR CUENTA PROPIA)';
    private const AUTOMATICO_OBJETO_PROYECTO_PAA = 'SERVICIOS DE DISTRIBUCIÓN DE ELECTRICIDAD, GAS Y AGUA (POR CUENTA PROPIA)';
    private const AUTOMATICO_INSUMO = 'EXCEDENTES NIVEL CENTRAL';
    private const AUTOMATICO_ACTIVIDAD = 'Contribución al uso de servicios públicos';
    private const AUTOMATICO_MES = 2;

    public function __construct()
    {
        $this->modeloGasto = new GastoUnisalud();
        $this->modeloIngreso = new IngresoUnisalud();
        $this->modeloLinea = new Linea();
        $this->modeloMotor = new Motor();
        $this->modeloProyecto = new Proyecto();
        $this->modeloRubro = new Rubro();
        $this->modeloAnio = new AnioPresupuestal();
        $this->modeloSede = new Sede();
        $this->modeloPorcentaje = new AutogestionPorcentaje();
        $this->modeloDependencia = new Dependencia();
        $this->modeloUsuario = new Usuario();
    }

    public function index(): void
    {
        if (empty($_SESSION['usuario_id'])) {
            header('Location: index.php?ruta=login');
            exit;
        }

        if ($_SESSION['usuario_rol'] !== 'administrador') {
            header('Location: index.php?ruta=dashboard');
            exit;
        }

        $error = '';
        $exito = '';
        $tab = ($_GET['tab'] ?? 'ingresos') === 'egresos' ? 'egresos' : 'ingresos';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tab = ($_POST['tab'] ?? 'ingresos') === 'egresos' ? 'egresos' : 'ingresos';
            $accion = $_POST['accion'] ?? '';

            if ($tab === 'egresos' && $accion === 'actualizar') {
                [$error, $exito] = $this->actualizarEgreso();
            } elseif ($tab === 'egresos' && $accion === 'eliminar') {
                [$error, $exito] = $this->eliminarEgreso();
            } elseif ($tab === 'ingresos' && $accion === 'actualizar') {
                [$error, $exito] = $this->actualizarIngreso();
            } elseif ($tab === 'ingresos' && $accion === 'eliminar') {
                [$error, $exito] = $this->eliminarIngreso();
            } else {
                [$error, $exito] = $tab === 'ingresos' ? $this->guardarIngreso() : $this->guardarEgreso();
            }
        }

        $lineas = $this->modeloLinea->obtenerTodas();
        $motores = $this->modeloMotor->obtenerTodos();
        $proyectos = $this->modeloProyecto->obtenerTodos();
        $rubros = $this->modeloRubro->obtenerActivos();
        $aniosActivos = $this->modeloAnio->obtenerActivos();
        $sedes = $this->modeloSede->obtenerTodas();
        $categoriasEgreso = self::CATEGORIAS_EGRESO;

        $usuarioActual = $this->modeloUsuario->obtenerPorId((int) $_SESSION['usuario_id']);
        $dependenciaUsuarioId = !empty($usuarioActual['dependencia_id']) ? (int) $usuarioActual['dependencia_id'] : null;
        $dependenciaUsuario = $dependenciaUsuarioId !== null ? $this->modeloDependencia->obtenerPorId($dependenciaUsuarioId) : null;
        $dependenciaUsuarioEsRaiz = $dependenciaUsuario !== null && !empty($dependenciaUsuario['es_raiz_superadmin']);

        $dependenciasSugeridas = [];
        $tieneHijas = false;
        $dependenciaPorDefecto = null;

        if ($dependenciaUsuario !== null) {
            $descendientes = $this->modeloDependencia->obtenerDescendientesPlano($dependenciaUsuarioId);
            $tieneHijas = !empty($descendientes);

            if (!$dependenciaUsuarioEsRaiz) {
                $dependenciasSugeridas[] = $dependenciaUsuario['nombre'];
                $dependenciaPorDefecto = $dependenciaUsuario['nombre'];
            }

            foreach ($descendientes as $descendiente) {
                if (!empty($descendiente['es_raiz_superadmin'])) {
                    continue;
                }

                $dependenciasSugeridas[] = $descendiente['nombre'];
            }
        }

        $anioSeleccionadoId = 0;

        if (!empty($aniosActivos)) {
            $anioSeleccionadoId = isset($_GET['anio_id']) ? (int) $_GET['anio_id'] : (int) $aniosActivos[0]['id'];

            $idsValidos = array_map('intval', array_column($aniosActivos, 'id'));
            if (!in_array($anioSeleccionadoId, $idsValidos, true)) {
                $anioSeleccionadoId = (int) $aniosActivos[0]['id'];
            }
        }

        if ($tab === 'ingresos') {
            $gastos = $anioSeleccionadoId > 0 ? $this->modeloIngreso->obtenerPorAnio($anioSeleccionadoId) : [];
        } else {
            $gastos = $anioSeleccionadoId > 0 ? $this->modeloGasto->obtenerPorAnio($anioSeleccionadoId) : [];
        }

        $gastosEgresos = $tab === 'egresos'
            ? $gastos
            : ($anioSeleccionadoId > 0 ? $this->modeloGasto->obtenerPorAnio($anioSeleccionadoId) : []);

        $anioSeleccionado = null;
        foreach ($aniosActivos as $anioFila) {
            if ((int) $anioFila['id'] === $anioSeleccionadoId) {
                $anioSeleccionado = $anioFila;
                break;
            }
        }

        $totalGastado = array_sum(array_map(static fn (array $g): float => (float) $g['valor_total'], $gastos));
        $totalEjecutado = array_sum(array_map(static fn (array $g): float => (float) $g['valor_total'], $gastosEgresos));
        $presupuestoAnio = $anioSeleccionadoId > 0 ? $this->modeloIngreso->obtenerTotalPorAnio($anioSeleccionadoId) : 0.0;
        $porcentajeGastado = $presupuestoAnio > 0 ? min(100, ($totalEjecutado / $presupuestoAnio) * 100) : 0.0;

        $totalCostos = 0.0;
        $totalInversion = 0.0;
        $totalExcedentes = 0.0;

        foreach ($gastosEgresos as $gasto) {
            $valor = (float) $gasto['valor_total'];
            $categoria = $gasto['categoria'];

            if ($categoria === 'Gastos' || str_starts_with($categoria, 'Costos')) {
                $totalCostos += $valor;
            } elseif ($categoria === 'Inversiones' || str_starts_with($categoria, 'Inversión')) {
                $totalInversion += $valor;
            } elseif (str_starts_with($categoria, 'Excedentes')) {
                $totalExcedentes += $valor;
            }
        }

        $pctCostos = $presupuestoAnio > 0 ? min(100, ($totalCostos / $presupuestoAnio) * 100) : 0.0;
        $pctInversion = $presupuestoAnio > 0 ? min(100, ($totalInversion / $presupuestoAnio) * 100) : 0.0;
        $pctExcedentes = $presupuestoAnio > 0 ? min(100, ($totalExcedentes / $presupuestoAnio) * 100) : 0.0;

        $diaActual = (int) date('z') + 1;
        $totalDiasAnio = date('L') ? 366 : 365;

        require __DIR__ . '/../vista/unisalud/index.php';
    }

    private function guardarEgreso(): array
    {
        [$datos, $error] = $this->validarDatosEgreso();

        if ($error !== '') {
            return [$error, ''];
        }

        $ingresosDisponibles = $this->modeloIngreso->obtenerTotalPorAnio($datos['anio_presupuestal_id']);
        $egresosActuales = $this->modeloGasto->obtenerTotalPorAnio($datos['anio_presupuestal_id']);
        $nuevoValor = $datos['cantidad'] * $datos['costo_unitario'];

        if ($egresosActuales + $nuevoValor > $ingresosDisponibles) {
            $disponible = max(0, $ingresosDisponibles - $egresosActuales);

            return ['Este egreso supera los ingresos disponibles de este año. Disponible: ' . number_format($disponible, 2) . '.', ''];
        }

        try {
            $this->modeloGasto->crear($datos);
        } catch (PDOException $excepcion) {
            return ['No se pudo registrar el egreso. Verifica el año, la sede, la línea, el motor, el proyecto y el rubro seleccionados.', ''];
        }

        return ['', 'Egreso registrado correctamente.'];
    }

    private function actualizarEgreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloGasto->obtenerPorId($id) : null;

        if ($existente === null || $existente['tipo_automatico'] !== null) {
            return ['El egreso que intentas editar no existe.', ''];
        }

        [$datos, $error] = $this->validarDatosEgreso();

        if ($error !== '') {
            return [$error, ''];
        }

        $ingresosDisponibles = $this->modeloIngreso->obtenerTotalPorAnio($datos['anio_presupuestal_id']);
        $egresosActuales = $this->modeloGasto->obtenerTotalPorAnio($datos['anio_presupuestal_id']) - (float) $existente['valor_total'];
        $nuevoValor = $datos['cantidad'] * $datos['costo_unitario'];

        if ($egresosActuales + $nuevoValor > $ingresosDisponibles) {
            $disponible = max(0, $ingresosDisponibles - $egresosActuales);

            return ['Este egreso supera los ingresos disponibles de este año. Disponible: ' . number_format($disponible, 2) . '.', ''];
        }

        try {
            $this->modeloGasto->actualizar($id, $datos);
        } catch (PDOException $excepcion) {
            return ['No se pudo actualizar el egreso. Verifica el año, la sede, la línea, el motor, el proyecto y el rubro seleccionados.', ''];
        }

        return ['', 'Egreso actualizado correctamente.'];
    }

    private function eliminarEgreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloGasto->obtenerPorId($id) : null;

        if ($existente === null || $existente['tipo_automatico'] !== null) {
            return ['El egreso que intentas eliminar no existe.', ''];
        }

        $this->modeloGasto->eliminar($id);

        return ['', 'Egreso eliminado correctamente.'];
    }

    private function validarDatosEgreso(): array
    {
        $datos = [];

        foreach ($_POST as $campo => $valor) {
            $datos[$campo] = is_string($valor) ? trim($valor) : $valor;
        }

        foreach (self::CAMPOS_REQUERIDOS_EGRESO as $campo) {
            if (($datos[$campo] ?? '') === '') {
                return [[], 'Todos los campos son obligatorios.'];
            }
        }

        if (!in_array($datos['categoria'], self::CATEGORIAS_EGRESO, true)) {
            return [[], 'Selecciona una categoría válida.'];
        }

        if (!is_numeric($datos['cantidad']) || (int) $datos['cantidad'] <= 0) {
            return [[], 'La cantidad debe ser un número entero mayor a 0.'];
        }

        if (!is_numeric($datos['costo_unitario']) || (float) $datos['costo_unitario'] < 0) {
            return [[], 'El costo unitario debe ser un número válido.'];
        }

        $meses = array_filter(
            array_map('intval', $datos['meses'] ?? []),
            static fn (int $mes): bool => $mes >= 1 && $mes <= 12
        );

        if (empty($meses)) {
            return [[], 'Selecciona al menos un mes de ejecución.'];
        }

        $meses = array_unique($meses);
        sort($meses);
        $datos['meses'] = implode(',', $meses);

        $datos['anio_presupuestal_id'] = (int) $datos['anio_presupuestal_id'];
        $datos['sede_id'] = (int) $datos['sede_id'];
        $datos['linea_id'] = (int) $datos['linea_id'];
        $datos['motor_id'] = (int) $datos['motor_id'];
        $datos['proyecto_id'] = (int) $datos['proyecto_id'];
        $datos['rubro_id'] = (int) $datos['rubro_id'];
        $datos['cantidad'] = (int) $datos['cantidad'];
        $datos['costo_unitario'] = (float) $datos['costo_unitario'];

        return [$datos, ''];
    }

    private function validarDatosIngreso(): array
    {
        $anioPresupuestalId = (int) ($_POST['anio_presupuestal_id'] ?? 0);
        $dependencia = trim($_POST['dependencia'] ?? '');
        $conceptoAdicional = trim($_POST['concepto_adicional'] ?? '');
        $valorAdicional = is_numeric($_POST['valor_adicional'] ?? '') ? (float) $_POST['valor_adicional'] : 0.0;

        if ($anioPresupuestalId <= 0 || $dependencia === '') {
            return [[], [], 'El año presupuestal y la dependencia son obligatorios.'];
        }

        if ($valorAdicional < 0) {
            return [[], [], 'El valor del concepto adicional no puede ser negativo.'];
        }

        $nombresConcepto = $_POST['concepto'] ?? [];
        $cantidades = $_POST['cantidad_concepto'] ?? [];
        $valores = $_POST['valor_concepto'] ?? [];

        $conceptos = [];
        $totalFilas = max(count($nombresConcepto), count($cantidades), count($valores));

        for ($indice = 0; $indice < $totalFilas; $indice++) {
            $nombre = trim($nombresConcepto[$indice] ?? '');
            $cantidad = $cantidades[$indice] ?? '';
            $valor = $valores[$indice] ?? '';

            if ($nombre === '' && $cantidad === '' && $valor === '') {
                continue;
            }

            if ($nombre === '' || !is_numeric($cantidad) || (int) $cantidad <= 0 || !is_numeric($valor) || (float) $valor < 0) {
                return [[], [], 'Cada concepto necesita un nombre, una cantidad mayor a 0 y un valor válido.'];
            }

            $conceptos[] = [
                'concepto' => $nombre,
                'cantidad' => (int) $cantidad,
                'valor' => (float) $valor,
            ];
        }

        if (empty($conceptos) && $valorAdicional <= 0) {
            return [[], [], 'Agrega al menos un concepto o un concepto adicional con valor.'];
        }

        $subtotalConceptos = array_sum(array_map(
            static fn (array $c): float => $c['cantidad'] * $c['valor'],
            $conceptos
        ));
        $valorTotal = $subtotalConceptos + $valorAdicional;

        $cabecera = [
            'anio_presupuestal_id' => $anioPresupuestalId,
            'dependencia' => $dependencia,
            'concepto_adicional' => $conceptoAdicional,
            'valor_adicional' => $valorAdicional,
            'valor_total' => $valorTotal,
        ];

        return [$cabecera, $conceptos, ''];
    }

    private function guardarIngreso(): array
    {
        [$cabecera, $conceptos, $error] = $this->validarDatosIngreso();

        if ($error !== '') {
            return [$error, ''];
        }

        try {
            $ingresoId = $this->modeloIngreso->crear($cabecera, $conceptos);
        } catch (PDOException $excepcion) {
            return ['No se pudo registrar el ingreso. Verifica el año presupuestal seleccionado.', ''];
        }

        $this->generarEgresosAutomaticos($ingresoId, $cabecera['anio_presupuestal_id'], $cabecera['dependencia']);

        return ['', 'Ingreso registrado correctamente.'];
    }

    private function actualizarIngreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloIngreso->obtenerPorId($id) : null;

        if ($existente === null) {
            return ['El ingreso que intentas editar no existe.', ''];
        }

        [$cabecera, $conceptos, $error] = $this->validarDatosIngreso();

        if ($error !== '') {
            return [$error, ''];
        }

        try {
            $this->modeloIngreso->actualizar($id, $cabecera, $conceptos);
        } catch (PDOException $excepcion) {
            return ['No se pudo actualizar el ingreso. Verifica el año presupuestal seleccionado.', ''];
        }

        $this->generarEgresosAutomaticos($id, $cabecera['anio_presupuestal_id'], $cabecera['dependencia']);

        return ['', 'Ingreso actualizado correctamente.'];
    }

    private function eliminarIngreso(): array
    {
        $id = (int) ($_POST['id'] ?? 0);
        $existente = $id > 0 ? $this->modeloIngreso->obtenerPorId($id) : null;

        if ($existente === null) {
            return ['El ingreso que intentas eliminar no existe.', ''];
        }

        $this->modeloIngreso->eliminar($id);
        $this->generarEgresosAutomaticos(
            null,
            (int) $existente['anio_presupuestal_id'],
            (string) $existente['dependencia']
        );

        return ['', 'Ingreso eliminado correctamente.'];
    }

    private function generarEgresosAutomaticos(?int $ingresoId, int $anioPresupuestalId, string $dependencia): void
    {
        $porcentajes = $this->modeloPorcentaje->obtenerPorModulo('unisalud');
        $totalIngresos = $this->modeloIngreso->obtenerTotalPorAnio($anioPresupuestalId);

        $costosNoAplica = $porcentajes['costos'] === null;
        $inversionesNoAplica = $porcentajes['inversiones'] === null;

        $lineas = [];

        if ($costosNoAplica && $inversionesNoAplica) {
            $porcentajeExcedentes = $porcentajes['excedentes'] !== null ? (float) $porcentajes['excedentes'] : 0.0;
            $lineas['costos_inversiones'] = [
                'porcentaje' => max(0, 100 - $porcentajeExcedentes),
                'etiqueta' => 'Costos e Inversión',
            ];
        } else {
            if (!$costosNoAplica) {
                $lineas['costos'] = ['porcentaje' => (float) $porcentajes['costos'], 'etiqueta' => 'Costos'];
            }

            if (!$inversionesNoAplica) {
                $lineas['inversiones'] = ['porcentaje' => (float) $porcentajes['inversiones'], 'etiqueta' => 'Inversión'];
            }
        }

        if ($porcentajes['excedentes'] !== null) {
            $lineas['excedentes'] = ['porcentaje' => (float) $porcentajes['excedentes'], 'etiqueta' => 'Excedentes nivel central'];
        }

        $this->modeloGasto->eliminarAutomaticosDistintosDe($anioPresupuestalId, array_keys($lineas));

        foreach ($lineas as $tipo => $info) {
            $valor = round($totalIngresos * $info['porcentaje'] / 100, 2);
            $porcentajeTexto = rtrim(rtrim(number_format($info['porcentaje'], 2), '0'), '.');

            $categoria = $info['etiqueta'] . ' (' . $porcentajeTexto . '%)';

            $datos = [
                'sede_id' => self::AUTOMATICO_SEDE_ID,
                'anio_presupuestal_id' => $anioPresupuestalId,
                'categoria' => $categoria,
                'dependencia' => $dependencia,
                'linea_id' => self::AUTOMATICO_LINEA_ID,
                'motor_id' => self::AUTOMATICO_MOTOR_ID,
                'proyecto_id' => self::AUTOMATICO_PROYECTO_ID,
                'objeto_proyecto_paa' => self::AUTOMATICO_OBJETO_PROYECTO_PAA,
                'actividad' => self::AUTOMATICO_ACTIVIDAD,
                'rubro_texto' => self::AUTOMATICO_RUBRO_TEXTO,
                'ingreso_id' => $ingresoId,
                'tipo_automatico' => $tipo,
                'insumo' => self::AUTOMATICO_INSUMO,
                'cantidad' => 1,
                'costo_unitario' => $valor,
                'valor_total' => $valor,
                'meses' => (string) self::AUTOMATICO_MES,
            ];

            $existente = $this->modeloGasto->obtenerAutomaticoPorTipo($anioPresupuestalId, $tipo);

            if ($existente !== null) {
                $this->modeloGasto->actualizarAutomatico((int) $existente['id'], $datos);
            } else {
                $this->modeloGasto->crearAutomatico($datos);
            }
        }
    }
}
