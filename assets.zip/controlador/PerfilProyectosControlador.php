<?php

require_once __DIR__ . '/../modelo/Necesidad.php';

class PerfilProyectosControlador
{
    private Necesidad $modeloNecesidad;

    public function __construct()
    {
        $this->modeloNecesidad = new Necesidad();
    }

    public function index(): void
    {
        if (empty($_SESSION['usuario_id'])) {
            header('Location: index.php?ruta=login');
            exit;
        }

        if ($_SESSION['usuario_rol'] !== 'administrador') {
            header('Location: index.php?ruta=dashboard');
            exit;
        }

        $necesidades = $this->modeloNecesidad->obtenerTodas();

        require __DIR__ . '/../vista/perfil-proyectos/index.php';
    }

    public function exportar(): void
    {
        if (empty($_SESSION['usuario_id'])) {
            header('Location: index.php?ruta=login');
            exit;
        }

        if ($_SESSION['usuario_rol'] !== 'administrador') {
            header('Location: index.php?ruta=dashboard');
            exit;
        }

        $necesidades = $this->modeloNecesidad->obtenerTodas();

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="perfil-proyectos-' . date('Y-m-d') . '.csv"');

        $salida = fopen('php://output', 'w');
        fwrite($salida, "\xEF\xBB\xBF");

        fputcsv($salida, [
            'Solicitante', 'Línea', 'Sublínea', 'Inversión (detalle)', 'Sede', 'Dependencia',
            'Programa académico', 'Proyecto PDI', 'Articulación con Plan/planes', 'Espacio a intervenir',
            'Requisitos normativos', 'Valor', 'Fuente de financiación', 'Responsable', 'Observaciones', 'Registrado',
        ], ';');

        foreach ($necesidades as $necesidad) {
            fputcsv($salida, [
                $necesidad['nombre_solicitante'],
                $necesidad['linea_inversion'],
                $necesidad['sublinea_inversion'],
                $necesidad['detalle_inversion'] ?? '',
                $necesidad['sede'],
                $necesidad['dependencia'],
                $necesidad['programa_academico'] ?? '',
                $necesidad['proyecto_pdi'] ?? '',
                $necesidad['articulacion_plan'] ?? '',
                $necesidad['espacio_intervenir'] ?? '',
                $necesidad['requisitos_normativos'] ?? '',
                number_format((float) $necesidad['valor'], 2, '.', ''),
                $necesidad['fuente_financiacion'],
                $necesidad['responsable'],
                $necesidad['observaciones'] ?? '',
                $necesidad['creado_en'],
            ], ';');
        }

        fclose($salida);
        exit;
    }
}
